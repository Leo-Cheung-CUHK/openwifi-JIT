#!/usr/bin/env python

import sys

#print "python file name",sys.argv[0]

#sum=0

#for i in range(1, len(sys.argv)):
#	print "args", i, sys.argv[i]
#	sum += int(sys.argv[i])

#print sum

L = []
try:
	f = open("/dev/my_misc","r")
	s = f.readline()
	s = s.rstrip()
	L.append(s)
	f.close()

except IOError:
	print("Open Error.")
print L

